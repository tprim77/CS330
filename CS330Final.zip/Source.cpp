/***************************************
* Author: Tyler Primas
* Date:  May 17, 2023
* Description: This program creates a 3d scene with several textured objects and lighting.
****************************************/


#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#include <GL/glew.h>
#include "camera.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Final Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nVertices;
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    GLMesh gSphereMesh;
    GLMesh gCubeMesh;
    GLMesh gPlaneMesh;
    GLMesh gFullSphereMesh;
    GLMesh gPyramidMesh;
    // Texture id
    GLuint gTextureId;
    GLuint gPlaneTextureId;
    GLuint gBallTextureId;
    GLuint gD4TextureId;
    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_LINEAR;
    // Shader program
    GLuint gProgramId;
    GLuint gLampProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
    glm::vec3 gCubeScale(2.0f);
    glm::vec3 gObjectColor(1.0f, 0.2f, 0.0f);
    // Light color, position, and scale
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);
    glm::vec3 gLightPosition(8.0f, 0.0f, -2.0f);
    glm::vec3 gLightScale(0.6f);

    glm::vec3 gLightColor2(0.0f, 0.0f, 1.0f);
    glm::vec3 gLightPosition2(-3.0f, 2.0f, -2.0f);
    glm::vec3 gLightScale2(0.6f);
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateSphereMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh);
void UCreateMesh(GLMesh& mesh);
void UCreatePlaneMesh(GLMesh& mesh);
void UCreateFullSphereMesh(GLMesh& mesh);
void UCreatePyramidMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);




/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;


//Global variables for the transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties

    vertexTextureCoordinate = textureCoordinate;
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 lightColor2;
uniform vec3 lightPos2;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.3f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 1.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;



    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);


    //Calculate Diffuse lighting for second light
    specularIntensity = 0.1f;
    vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos);
    float impact2 = max(dot(norm, lightDirection2), 0.0);
    vec3 diffuse2 = impact2 * lightColor2;

    //Calculate Specular lighting for second light
    vec3 reflectDir2 = reflect(-lightDirection2, norm);
    float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize);
    vec3 specular2 = specularIntensity * specularComponent2 * lightColor2;


    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular + diffuse2 + specular2) * textureColor.xyz;


    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the meshes for each object
    UCreateSphereMesh(gSphereMesh); // Calls the function to create the Vertex Buffer Object
    UCreateCubeMesh(gCubeMesh);
    UCreatePlaneMesh(gPlaneMesh);
    UCreateFullSphereMesh(gFullSphereMesh);
    UCreatePyramidMesh(gPyramidMesh);
    UCreateMesh(gMesh);

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load texture
    const char* texFilename = "Textures/wood.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "Textures/desk.jpg";
    if (!UCreateTexture(texFilename, gPlaneTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "Textures/ball.png";
    if (!UCreateTexture(texFilename, gBallTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "Textures/D4.png";
    if (!UCreateTexture(texFilename, gD4TextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureId);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, gPlaneTextureId);
        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, gBallTextureId);
        glActiveTexture(GL_TEXTURE3);
        glBindTexture(GL_TEXTURE_2D, gD4TextureId);
        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame

        URender();


        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gSphereMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gFullSphereMesh);
    UDestroyMesh(gPyramidMesh);

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}



// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;
    bool perspective = true;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    //incorporated UP and DOWN from camera header file 
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        perspective = false;
        glm::mat4 projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    //updated ProcessMouseScroll to control the speed of the camera movement
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}



// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 2
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    // 2. Rotates shape by 2 degrees in the y axis
    glm::mat4 rotation = glm::rotate(2.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();


    // Creates a perspective projection
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Cube Shader program for the cube color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

    glUniform3fv(glGetUniformLocation(gProgramId, "lightColor2"), 1, glm::value_ptr(gLightColor2));
    glUniform3fv(glGetUniformLocation(gProgramId, "lightPos2"), 1, glm::value_ptr(gLightPosition2));

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCubeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

  

    //load sphere texture

    glBindVertexArray(gSphereMesh.vao);
    glBindVertexArray(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId);
    glDrawElements(GL_TRIANGLES, gSphereMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the sphere
    //  // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    //load cube
    glBindVertexArray(gMesh.vao);
    glBindVertexArray(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gD4TextureId);
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the sphere
    //  // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    //load plane texture
    glBindVertexArray(gPlaneMesh.vao);
    glBindVertexArray(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gPlaneTextureId);
    //// Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    //load sphere texture
    glBindVertexArray(gFullSphereMesh.vao);
    glBindVertexArray(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gBallTextureId);
    glDrawElements(GL_TRIANGLES, gFullSphereMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the sphere
    //  // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    //load pyramid texture
    glBindVertexArray(gPyramidMesh.vao);
    glBindVertexArray(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gD4TextureId);
    //// Draws the triangles
    glDrawElements(GL_TRIANGLES, gPyramidMesh.nIndices, GL_UNSIGNED_INT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // LAMP: draw lamp
 //----------------
    glUseProgram(gLampProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);


    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);



    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

void UCreateMesh(GLMesh& mesh)
{
    GLfloat verts[] = {
        // Vertex Positions         // Normals                // Texture Coordinates
        // Front face
        -0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,      0.0f, 0.0f, 1.0f,          0.0f, 0.0f,  // Front bottom left vertex
        0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,       0.0f, 0.0f, 1.0f,          1.0f, 0.0f,  // Front bottom right vertex
        0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,        0.0f, 0.0f, 1.0f,          1.0f, 1.0f,  // Front top right vertex
        -0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,       0.0f, 0.0f, 1.0f,          0.0f, 1.0f,  // Front top left vertex

        // Back face
        -0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,       0.0f, 0.0f, -1.0f,         1.0f, 0.0f,  // Back bottom left vertex
        0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,        0.0f, 0.0f, -1.0f,         0.0f, 0.0f,  // Back bottom right vertex
        0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,         0.0f, 0.0f, -1.0f,         0.0f, 1.0f,  // Back top right vertex
        -0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,        0.0f, 0.0f, -1.0f,         1.0f, 1.0f,  // Back top left vertex

        // Left face
        -0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,       -1.0f, 0.0f, 0.0f,         0.0f, 0.0f,  // Left bottom back vertex
        -0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,      -1.0f, 0.0f, 0.0f,          1.0f, 0.0f,  // Left bottom front vertex
        -0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,       -1.0f, 0.0f, 0.0f,          1.0f, 1.0f,  // Left top front vertex
        -0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,        -1.0f, 0.0f, 0.0f,          0.0f, 1.0f,  // Left top back vertex

        // Right face
        0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,        1.0f, 0.0f, 0.0f,          0.0f, 0.0f,  // Right bottom front vertex
        0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,       1.0f, 0.0f, 0.0f,          1.0f, 0.0f,  // Right bottom back vertex
        0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,        1.0f, 0.0f, 0.0f,          1.0f, 1.0f,  // Right top back vertex
        0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,         1.0f, 0.0f, 0.0f,          0.0f, 1.0f,  // Right top front vertex

        // Top face
        -0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,       0.0f, 1.0f, 0.0f,          0.0f, 0.0f,  // Top front left vertex
        0.5f + 3.0f, 0.5f - 0.3f, -0.5f - 2.0f,        0.0f, 1.0f, 0.0f,          1.0f, 0.0f,  // Top front right vertex
        0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,         0.0f, 1.0f, 0.0f,          1.0f, 1.0f,  // Top back right vertex
        -0.5f + 3.0f, 0.5f - 0.3f, 0.5f - 2.0f,        0.0f, 1.0f, 0.0f,          0.0f, 1.0f,  // Top back left vertex

        // Bottom face
        -0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,      0.0f, -1.0f, 0.0f,         0.0f, 0.0f,  // Bottom front left vertex
        0.5f + 3.0f, -0.5f - 0.3f, -0.5f - 2.0f,       0.0f, -1.0f, 0.0f,         1.0f, 0.0f,  // Bottom front right vertex
        0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,        0.0f, -1.0f, 0.0f,         1.0f, 1.0f,  // Bottom back right vertex
        -0.5f + 3.0f, -0.5f - 0.3f, 0.5f - 2.0f,       0.0f, -1.0f, 0.0f,         0.0f, 1.0f   // Bottom back left vertex
    };

    GLfloat scalingFactor = 0.74f;

    for (int i = 0; i < sizeof(verts) / sizeof(GLfloat); i += 8) {
        verts[i] *= scalingFactor;      // X coordinate
        verts[i + 1] *= scalingFactor;  // Y coordinate
        verts[i + 2] *= scalingFactor;  // Z coordinate
    }

    GLushort indices[] = {
        0, 1, 2,  // Front face
        0, 2, 3,
        4, 5, 6,  // Back face
        4, 6, 7,
        8, 9, 10, // Left face
        8, 10, 11,
        12, 13, 14, // Right face
        12, 14, 15,
        16, 17, 18, // Top face
        16, 18, 19,
        20, 21, 22, // Bottom face
        20, 22, 23
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Vertex positions
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    // Normals
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    // Texture coordinates
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Implements the UCreateMesh function
void UCreateCubeMesh(GLMesh& mesh)
{
    // Position, Normal, and Texture Coordinate data
    GLfloat verts[] = {
        // Vertex Positions      // Normals                  // Texture Coordinates
        // Front face
        0.98f,  -0.1f,  0.0625f,    0.0f, 0.0f, 1.0f,         0.0f, 0.0f, // 0
        7.0f,  -0.1f,  0.0625f,     0.0f, 0.0f, 1.0f,         1.0f, 0.0f, // 1
        7.0f, -0.225f,  0.0625f,    0.0f, 0.0f, 1.0f,         1.0f, 1.0f, // 2
        0.92f, -0.225f,  0.0625f,   0.0f, 0.0f, 1.0f,         0.0f, 1.0f, // 3

        // Back face
        0.98f,  -0.1f, -0.0625f,    0.0f, 0.0f, -1.0f,        0.0f, 0.0f, // 4
        7.0f,  -0.1f, -0.0625f,     0.0f, 0.0f, -1.0f,        1.0f, 0.0f, // 5
        7.0f, -0.225f, -0.0625f,    0.0f, 0.0f, -1.0f,        1.0f, 1.0f, // 6
        0.92f, -0.225f, -0.0625f,   0.0f, 0.0f, -1.0f,        0.0f, 1.0f, // 7
    };

    GLushort indices[] = {
        // Front face
        0, 1, 2,
        0, 2, 3,

        // Back face
        4, 6, 5,
        4, 7, 6,

        // Left face
        4, 5, 1,
        4, 1, 0,

        // Right face
        3, 2, 6,
        3, 6, 7,

        // Top face
        0, 3, 7,
        0, 7, 4,

        // Bottom face
        1, 5, 6,
        1, 6, 2,
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(indices) / sizeof(indices[0]);

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}

void UCreateFullSphereMesh(GLMesh& mesh)
{
    const float radius = 0.88f; // Radius of the sphere
    const int numSlices = 50; // Number of slices (horizontal divisions)
    const int numStacks = 25; // Number of stacks (vertical divisions)
    const float elongation = 1.0f;
    const float offset = 0.28f;

    std::vector<GLfloat> sphereVerts;
    std::vector<GLushort> sphereIndices;

    // Generate sphere vertices
    for (int stack = numStacks; stack >= 0; --stack) // Loop in reverse order
    {
        float phi = stack * glm::pi<float>() / numStacks;
        float y = -radius * elongation * cos(phi) + offset; // Flip the y-coordinate and flatten out
        for (int slice = 0; slice <= numSlices; ++slice)
        {
            float theta = slice * 2 * glm::pi<float>() / numSlices;
            float x = radius * sin(phi) * cos(theta) + 2;
            float z = radius * sin(phi) * sin(theta) + 2;

            sphereVerts.push_back(x);
            sphereVerts.push_back(y);
            sphereVerts.push_back(z);

            // Calculate texture coordinates
            float u = static_cast<float>(slice) / numSlices;
            float v = static_cast<float>(stack) / numStacks;

            sphereVerts.push_back(u);
            sphereVerts.push_back(v);

            // Calculate the normal
            glm::vec3 vertexPosition(x, y, z);
            glm::vec3 normal = glm::normalize(vertexPosition);

            sphereVerts.push_back(normal.x);
            sphereVerts.push_back(normal.y);
            sphereVerts.push_back(normal.z);
        }
    }

    // Generate sphere indices
    for (int stack = 0; stack < numStacks; ++stack)
    {
        for (int slice = 0; slice < numSlices; ++slice)
        {
            int topLeft = (stack * (numSlices + 1)) + slice;
            int topRight = topLeft + 1;
            int bottomLeft = topLeft + numSlices + 1;
            int bottomRight = bottomLeft + 1;

            // Reverse the winding order of the indices
            sphereIndices.push_back(topLeft);
            sphereIndices.push_back(topRight);
            sphereIndices.push_back(bottomLeft);

            sphereIndices.push_back(bottomLeft);
            sphereIndices.push_back(topRight);
            sphereIndices.push_back(bottomRight);
        }
    }
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNormal = 3;


    GLuint VAOs[2], VBOs[2], EBOs[2];
    glGenVertexArrays(2, VAOs);
    glGenBuffers(2, VBOs); //3?
    glGenBuffers(2, EBOs);

    //glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    GLuint vao = mesh.vao = VAOs[0];
    glBindVertexArray(vao);

    GLuint vboVertex = mesh.vbos[0] = VBOs[0];
    glBindBuffer(GL_ARRAY_BUFFER, vboVertex);
    glBufferData(GL_ARRAY_BUFFER, sphereVerts.size() * sizeof(GLfloat), &sphereVerts[0], GL_STATIC_DRAW);

    GLuint vboNormal = mesh.vbos[1] = VBOs[1];
    glBindBuffer(GL_ARRAY_BUFFER, vboNormal);
    glBufferData(GL_ARRAY_BUFFER, sphereVerts.size() * sizeof(GLfloat), &sphereVerts[0], GL_STATIC_DRAW);

    GLuint vboIndex = mesh.vbos[1] = EBOs[0];
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vboIndex);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphereIndices.size() * sizeof(GLushort), &sphereIndices[0], GL_STATIC_DRAW);

    GLsizei stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerNormal);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerUV)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    mesh.nIndices = sphereIndices.size();

}

void UCreateSphereMesh(GLMesh& mesh)
{
    const float radius = 1.0f; // Radius of the half sphere
    const int numSlices = 50; // Number of slices (horizontal divisions)
    const int numStacks = 25; // Number of stacks (vertical divisions)
    const float elongation = 0.6f;
    const float offset = 0.5f; //y offset


    std::vector<GLfloat> sphereVerts;
    std::vector<GLushort> sphereIndices;

    // Generate sphere vertices
    for (int stack = numStacks / 2; stack >= 0; --stack) // Loop in reverse order
    {
        float phi = stack * glm::pi<float>() / numStacks;
        float y = -radius * elongation * cos(phi); // Flip the y-coordinate and flatten out
        for (int slice = 0; slice <= numSlices; ++slice)
        {
            float theta = slice * 2 * glm::pi<float>() / numSlices;
            float x = radius * sin(phi) * cos(theta);
            float z = radius * sin(phi) * sin(theta);

            sphereVerts.push_back(x);
            sphereVerts.push_back(y);
            sphereVerts.push_back(z);

            // Calculate texture coordinates
            float u = static_cast<float>(slice) / numSlices;
            float v = static_cast<float>(stack) / (numStacks / 2);

            sphereVerts.push_back(u);
            sphereVerts.push_back(v);

            // Calculate the normal
            glm::vec3 vertexPosition(x, y, z);
            glm::vec3 normal = glm::normalize(vertexPosition);

            sphereVerts.push_back(normal.x);
            sphereVerts.push_back(normal.y);
            sphereVerts.push_back(normal.z);
        }
    }

    // Generate sphere indices
    for (int stack = 0; stack < numStacks / 2; ++stack)
    {
        for (int slice = 0; slice < numSlices; ++slice)
        {
            int topLeft = (stack * (numSlices + 1)) + slice;
            int topRight = topLeft + 1;
            int bottomLeft = topLeft + numSlices + 1;
            int bottomRight = bottomLeft + 1;

            // Reverse the winding order of the indices
            sphereIndices.push_back(topLeft);
            sphereIndices.push_back(topRight);
            sphereIndices.push_back(bottomLeft);

            sphereIndices.push_back(bottomLeft);
            sphereIndices.push_back(topRight);
            sphereIndices.push_back(bottomRight);
        }
    }

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNormal = 3;

    GLuint VAOs[2], VBOs[2], EBOs[2];
    glGenVertexArrays(2, VAOs);
    glGenBuffers(2, VBOs);
    glGenBuffers(2, EBOs);

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    GLuint vao = mesh.vao = VAOs[0];
    glBindVertexArray(vao);

    GLuint vboVertex = mesh.vbos[0] = VBOs[0];
    glBindBuffer(GL_ARRAY_BUFFER, vboVertex);
    glBufferData(GL_ARRAY_BUFFER, sphereVerts.size() * sizeof(GLfloat), &sphereVerts[0], GL_STATIC_DRAW);

    GLuint vboIndex = mesh.vbos[1] = EBOs[0];
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vboIndex);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphereIndices.size() * sizeof(GLushort), &sphereIndices[0], GL_STATIC_DRAW);

    GLsizei stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerNormal);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerUV)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    mesh.nIndices = sphereIndices.size();
}

void UCreatePlaneMesh(GLMesh& mesh)
{
    GLfloat verts[] = {
 
        // Vertex Positions    // Texture Coordinates (u,v)
        -3.5f, -0.6f,  5.5f,  0.0f, 1.0f, 0.0f,    0.0f, 1.0f, // Top-left
        8.5f, -0.6f,  5.5f,  1.0f, 1.0f, 0.0f,     1.0f, 1.0f, // Top-right
        -3.5f, -0.6f, -5.5f,  0.0f, 0.0f, 0.0f,     0.0f, 0.0f, // Bottom-left
        8.5f, -0.6f, -5.5f,  1.0f, 0.0f, 0.0f,      1.0f, 0.0f, // Bottom-right
    };

    GLushort indices[] = {
        0, 1, 2, // Triangle 1
        1, 3, 2, // Triangle 2
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNormal = 3;
    //display as see through
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerNormal);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerUV)));
    glEnableVertexAttribArray(1);
}

void UCreatePyramidMesh(GLMesh& mesh)
{
    GLfloat verts[] = {
        // Vertex Positions          // Normals                // Texture Coordinates
        4.0f,  0.4f,  -2.0f,          0.0f, 1.0f, 0.0f,         0.5f, 1.0f,  // Top vertex
        3.5f, -0.6f,  -1.5f,          -0.5f, 0.0f, -0.5f,      0.0f, 0.0f,  // Bottom front-left vertex
        4.5f, -0.6f,  -1.5f,          0.5f, 0.0f, -0.5f,       1.0f, 0.0f,  // Bottom front-right vertex
        4.0f, -0.6f, -2.5f,          0.0f, 0.0f, 1.0f,        0.5f, 1.0f   // Bottom back vertex
    };

    GLuint indices[] = {
        0, 1, 2,  // Front face
        0, 2, 3,  // Right face
        0, 3, 1,  // Left face
        1, 3, 2   // Bottom face
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Vertex positions
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    // Normals
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    // Texture coordinates
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}



void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, mesh.vbos);
}

/*Generate and load the texture*/
// Function to create a texture from an image file
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (!image)
    {
        cout << "Failed to load texture image: " << filename << endl;
        return false;
    }

    // Flip the image vertically
    flipImageVertically(image, width, height, channels);

    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);

    // Set texture parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Load the texture image data into OpenGL
    if (channels == 3)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    }
    else if (channels == 4)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    }

    // Generate mipmaps for the texture
    glGenerateMipmap(GL_TEXTURE_2D);

    // Unbind the texture
    glBindTexture(GL_TEXTURE_2D, 0);

    // Free the image data
    stbi_image_free(image);

    return true;
}



void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

